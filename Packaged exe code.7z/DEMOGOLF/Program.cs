﻿using Newtonsoft.Json;
using System;
using System.Data;
using System.IO;
using System.Windows.Forms;

namespace DEMOGOLF
{
    internal class Program
    {
        [STAThreadAttribute]
        static void Main(string[] args)
        {
            string tempString;
            DateTime startDate;
            DateTime endDate;

            Console.WriteLine("Insert Start Date (YYYY-MM-DD): ");
            tempString = Console.ReadLine();
            while (!DateTime.TryParseExact(tempString, "yyyy-MM-dd", null, System.Globalization.DateTimeStyles.None, out startDate))
            {
                Console.WriteLine("Invalid date, please retry (Press [Ctrl] + [C] to Exit");
                tempString = Console.ReadLine();
            }
            startDate = DateTime.Parse(tempString);

            Console.WriteLine("Insert End Date (YYYY-MM-DD): ");
            tempString = Console.ReadLine();
            while (!DateTime.TryParseExact(tempString, "yyyy-MM-dd", null, System.Globalization.DateTimeStyles.None, out endDate))
            {
                Console.WriteLine("Invalid date, please retry (Press [Ctrl] + [C] to Exit");
                tempString = Console.ReadLine();
            }
            endDate = DateTime.Parse(tempString);

            DataSet oDataSet = new DataSet();
            SQLDB cSQLDB = new SQLDB();
            string sQuery = "";
            try
            {
                sQuery = "";
                sQuery = sQuery + "EXEC SP_SELECT_PS_TKT_HIST '" + startDate.ToString() + "', '" + endDate.ToString() + "' ";
                cSQLDB.QueryDBF(sQuery, oDataSet, "SALES");
                var JSONString = "";
                JSONString = JsonConvert.SerializeObject(oDataSet.Tables);
                Console.WriteLine();
                Console.WriteLine(JSONString);
                Console.WriteLine();
                using (StreamWriter outputFile = new StreamWriter(Path.Combine(Application.StartupPath, "File")))
                {
                    foreach (char line in JSONString)
                        outputFile.Write(line);
                }
                Console.WriteLine("File generated. Please see output in .Exe folder");
                Clipboard.SetText(JSONString);
                Console.WriteLine("JSON string is automatically copied in the Clipboard, you may paste it wherever you like.");
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            finally
            {
                cSQLDB.Dispose();
            }
            Console.WriteLine();
            Console.WriteLine("Press any key to exit...");
            Console.ReadKey();
        }
    }
}

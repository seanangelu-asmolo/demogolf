﻿using System;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;

public class SQLDB : IDisposable
{
    private SqlConnection SQLConn;

    public SQLDB(string DataSource = "")
    {
        // HAVE TO CHANGE THIS CONNECTION STRING TO WORK IN OTHER MACHINES
        //string connectionString = ConfigurationManager.AppSettings["connectionString"];
        SQLConn = new SqlConnection(@"Server=localhost\SQLEXPRESS;Database=DEMOGOLF;Trusted_Connection=True;");
    }

    private bool disposed = false;

    // IDisposable
    private new void Dispose(bool disposing)
    {
        if (!this.disposed)
        {
            if (disposing)
            {
                if (SQLConn.State == ConnectionState.Open)
                    SQLConn.Close();
                SQLConn.Dispose();
            }
            SQLConn = null;
        }
        this.disposed = true;
    }

    public new void Dispose()
    {
        Dispose(true);
        GC.SuppressFinalize(this);
    }

    ~SQLDB()
    {
        Dispose(false);
        //base.Finalize();
    }

    protected void Open()
    {
        if (SQLConn.State != ConnectionState.Open)
            SQLConn.Open();
    }

    protected void Close()
    {
        if (SQLConn.State != ConnectionState.Closed)
            SQLConn.Close();
    }

    // +--------------
    // | Property    :   IsConnected()
    // | Description :   Check Connection State
    // +--------------
    public bool IsConnected
    {
        get
        {
            try
            {
                Open();
                return SQLConn.State == ConnectionState.Open;
            }
            catch (Exception ex)
            {
                return false;
                throw ex;
            }
            finally
            {
                Close();
            }
        }
    }

    // QueryDBF(ByVal cSqlStmt As String) - Overload
    public void QueryDBF(string cSqlStmt)
    {
        SqlCommand cmd;
        //OleDbCommand cmd;
        try
        {
            Open();
            //cmd = new OleDbCommand(cSqlStmt, SQLConn);
            cmd = new SqlCommand(cSqlStmt, SQLConn);
            cmd.ExecuteNonQuery();
        }
        catch (Exception ex)
        {
            throw ex;
        }
        finally
        {
            // cmd.Dispose()
            cmd = null;
            Close();
        }
    }

    // QueryDBF(ByVal cSqlStmt As String, ByVal oDataSet As DataSet, ByVal cTableName As String) - Overload
    public void QueryDBF(string cSqlStmt, DataSet oDataSet, string cTableName)
    {
        //OleDbDataAdapter tmpDataAdapter;
        SqlDataAdapter tmpDataAdapter;
        try
        {
            Open();
            //tmpDataAdapter = new OleDbDataAdapter(cSqlStmt, SQLConn);
            tmpDataAdapter = new SqlDataAdapter(cSqlStmt, SQLConn);
            tmpDataAdapter.Fill(oDataSet, cTableName);
        }
        catch (Exception ex)
        {
            throw ex;
        }
        finally
        {
            //tmpDataAdapter.Dispose();
            tmpDataAdapter = null;
            Close();
        }
    }
}
